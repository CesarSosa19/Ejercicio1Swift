import UIKit

var saludo = "Hola Mundo"

print(saludo)

// Cesar Sosa
/*
 Cesar Sosa
 MAC
 21 Anhos
 */

var nombre1: String = "Cesar"
var bool: Bool = true
var edad1: Int = 21

var var1: Int?
var var2: Int?
var var3: Int?
var var4: Int?

var usuario: String = "cesar"
var temperatura: Double = 16.5
var numero: Int = 1
var direccion: String = "acatlan"

let nombre: String = "Cesar"
let apellido: String = "Sosa"
var edad: Int = 21


